package mpsystem;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Student extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 String regno=request.getParameter("regno");
			String name=request.getParameter("name");
		
		
		 
		  try {
			  PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taskm","root","Maruthu@1");
		    PreparedStatement ps=con.prepareStatement("select * from taskm.student");
		    
		   
		     ResultSet rs=ps.executeQuery();
		     

		     while(rs.next()){
		    	 if(rs.getString("regno").equals(regno)&&rs.getString("name").equals(name)) {
		    	
		    		 
		    		 
		    		 
		    		 response.setContentType("text/html");	 
		    		 RequestDispatcher rq=request.getRequestDispatcher("Home.jsp");
		    		 rq.include(request, response);
		    		 out.println("<html>");
		    		 out.println("<head>");
		    		 out.println("<title>Table Example</title>");
		    		 out.println("</head>");
		    		 out.println("<body>");
		    		 out.print("<table border='1' width='50%'>");
		    		 
		    		 out.println("<tr><th>Register Number</th><th>Name</th><th>Tamil</th><th>English</th><th>Maths</th><th>Science</th><th>Social science</th></tr>");
		    		 out.println("<tr>"
		    		 		+ "<td>"+rs.getString("regno")+"</td>"
		    		 		+ "<td>"+rs.getString("name")+"</td>"
		    		 		+ "<td>"+rs.getString("tamil") +"</td>"
		    		 		+"<td>"+rs.getString("english") +"</td>"
		    		 		+"<td>"+rs.getString("maths") +"</td>"
		    		 		+"<td>"+rs.getString("science") +"</td>"
		    		 		//+"<td>"+rs.getString("social") +"</td>"
		    		 		+"<td>"+rs.getString("social") +"</td></tr>");
		    		
		    		 out.println("</table>");
		    		 out.println("</body>");
		    		 out.println("</html>");
		    		 out.close();
//		    		 response.setContentType("text/html");	 
//		    		 RequestDispatcher rq=request.getRequestDispatcher("Home.jsp");
//		    		 rq.include(request, response);
//		    	     pw.write("     RegNO:-"+rs.getString("regno"));
//		    		 pw.write("  ,Name:-  " +rs.getString("name"));
//		    		 pw.write("  ,Tamil:-  "+rs.getString("tamil"));
//		    		 pw.write("  ,English:-  "+rs.getString("english"));
//		    		 pw.write("  ,Maths:- "+rs.getString("maths")+'\n');
//		    		 pw.write("  ,Science:- "+rs.getString("science"));
//		    		 pw.write("  ,Social:- "+rs.getString("social"));
//		    		 
//		    		
		    		 break;


		  }
		    	  
		     }
		     } catch (Exception e) {
			
			e.printStackTrace();
		}

	
	
	}

}
