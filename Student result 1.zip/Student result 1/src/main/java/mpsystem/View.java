package mpsystem;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class View extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		 try {
			 PrintWriter out=response.getWriter();
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/taskm","root","Maruthu@1");
		    PreparedStatement ps=con.prepareStatement("select * from taskm.student ");
		    ResultSet rs=ps.executeQuery();
		    response.setContentType("text/html");
		    RequestDispatcher rq=request.getRequestDispatcher("Home.jsp");
   		 rq.include(request, response);
		    out.print("<table border='1' width='50%'>");
   		 
   		 out.println("<tr><th>Register Number</th><th>Name</th><th>Tamil</th><th>English</th><th>Maths</th><th>Science</th><th>Social science</th></tr>");
		    while (rs.next()){
		    	
		    		
	    		
	    		 out.println("<tr>"
	    		 		+ "<td>"+rs.getString("regno")+"</td>"
	    		 		+ "<td>"+rs.getString("name")+"</td>"
	    		 		+ "<td>"+rs.getString("tamil") +"</td>"
	    		 		+"<td>"+rs.getString("english") +"</td>"
	    		 		+"<td>"+rs.getString("maths") +"</td>"
	    		 		+"<td>"+rs.getString("science") +"</td>"
	  
	    		 		+"<td>"+rs.getString("social") +"</td></tr>");
	    		  	 
		    }
		} catch (Exception e) {
	
			e.printStackTrace();
		}
	
	}

}
